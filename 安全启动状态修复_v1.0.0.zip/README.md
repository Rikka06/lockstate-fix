# 安全启动状态修复 (SecureBoot Fix)

开机自动锁定 `ro.secureboot.lockstate` 为 `locked`，解决因安全启动状态异常导致的证书链篡改提示与环境检测异常。

## 作者信息与交流
- **作者**: XIAN
- **交流QQ群**: 605389940
- **酷安主页**: https://www.coolapk.com/u/3564176
- **哔哩哔哩**: https://b23.tv/Zks8L7W
- **抖音主页**: https://v.douyin.com/oFVtoEuk6yQ/
